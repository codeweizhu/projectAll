function gsapAni() {

  //- 想學gsap動畫可以移駕README.MD 有傳送門
}
