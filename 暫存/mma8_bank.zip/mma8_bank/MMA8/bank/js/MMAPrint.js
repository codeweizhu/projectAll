﻿function showData() {
    try {
        if (window.opener.document.getElementById("PrintContent").innerHTML == "") {
            window.close();
        } else {
            document.getElementById("PrintContent").innerHTML = window.opener.document.getElementById("PrintContent").innerHTML;

            // for 基金庫存總覽列印 ~ 用以隱藏 最後一列的「基金資訊」
            //******************************************************************************************
            var pURL = window.opener.location.toString();            
            var aURL = pURL.split("/");
            if (aURL[aURL.length - 1] == "gCert_First.aspx") 
            {
                var objS = document.getElementsByTagName("TABLE");

                var objData = objS[objS.length - 1];

                for (var iTR = 0; iTR < objData.getElementsByTagName("TR").length; iTR++) 
                {
                    if (iTR == 0) {
                        objTD = objData.getElementsByTagName("TR")[iTR].getElementsByTagName("TH");
                    }
                    else {
                        objTD = objData.getElementsByTagName("TR")[iTR].getElementsByTagName("TD");
                    }

                    objTD[objTD.length - 1].style.display = "none";                
                }                
            }
            //******************************************************************************************
            
            print();
        }
    }
    catch (e)
    { }
}