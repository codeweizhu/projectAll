$(document).ready(function () {
  dotableradius();

  $('.data-table tr:last-child').find('th, td').css('border-bottom', 'none');

  $('.dynlast li:last-child').addClass('last');
  $('.dynlast-bt li:last-child a').addClass('clear-last-bt');

  $(
    '.searchbar .rowElem,.index_fund .rowElem,.con_fund .rowElem,.con_bondinsure .rowElem,.search-area .rowElem'
  ).fancyfields();

  $('.moneyFormat').blur(function () {
    str = $(this).val().replace(/\D+/g, '');
    $(this).val(moneyFormat(str));
  });

  $('.ff').fancyfields();

  if ($('.selectWrapper').length) {
    $('.selectWrapper').dropdown();
  }

  $('#datepicker').datepicker({
    showOn: 'both',
    buttonImage: '/MMA8/bank/images/calendar.gif',
    buttonImageOnly: true,
    dateFormat: 'yy/mm/dd',
  });
  $('.datepicker-from').datepicker({
    showOn: 'both',
    buttonImage: '/MMA8/bank/images/calendar.gif',
    buttonImageOnly: true,
    dateFormat: 'yy/mm/dd',
    onClose: function (selectedDate) {
      $('.datepicker-to').datepicker('option', 'minDate', selectedDate);
    },
  });
  $('.datepicker-to').datepicker({
    showOn: 'both',
    buttonImage: '/MMA8/bank/images/calendar.gif',
    buttonImageOnly: true,
    dateFormat: 'yy/mm/dd',
    onClose: function (selectedDate) {
      $('.datepicker-from').datepicker('option', 'maxDate', selectedDate);
    },
  });
  // var at = $.url().param('at');
  // $('.main-menu .nav-lv1 > li').each(function(){
  //     if ($(this).attr('class').indexOf(at) != -1) {
  //         $(this).find('a').addClass('active');
  //     }
  // });

  function moneyFormat(str) {
    if (str.length <= 3) {
      return str;
    } else {
      return (
        moneyFormat(str.substr(0, str.length - 3)) +
        ',' +
        str.substr(str.length - 3)
      );
    }
  }

  var searchOpen = 0;
  var ffClick = true;
  $('#icon-search').click(function (e) {
    e.preventDefault();
    if ((searchOpen ^= 1)) {
      $(this).addClass('active');
      $('#search-block').show();
      if (ffClick) {
        $('.srowElem').fancyfields();
        ffClick = false;
      }
    } else {
      $(this).removeClass('active');
      $('#search-block').hide();
    }
  });

  $(document).mouseup(function (e) {
    var searchBlock = $('#search-block,#ui-id-1');
    if (onTarget(e, searchBlock)) {
      searchBlock.hide();
      $('#icon-search').removeClass('active');
    }
    var slideMenuWrapper = $('#slide-menu-wrapper');
    if (onTarget(e, slideMenuWrapper)) {
      slideMenuWrapper.slideUp('fast');
      $('.nav-lv1 .watermark').slideUp('fast');
    }
    var sbnavlv2 = $('.sbnav-lv2');
    if (onTarget(e, sbnavlv2)) {
      sbnavlv2.hide();
    }
    var sbnavlv3 = $('.sbnav-lv3');
    if (onTarget(e, sbnavlv3)) {
      sbnavlv3.hide();
    }
  });

  function onTarget(e, selector) {
    return !selector.is(e.target) && selector.has(e.target).length === 0;
  }

  var currMenu = null;
  $('.nav-lv1 > li a').click(function (e) {
    if (checkHref2go(e.target)) {
      e.preventDefault();
      var theClass = $(this).parent().attr('class');
      if (theClass.indexOf(currMenu) == -1) {
        $('#' + $(this).parent().data('mid')).fadeIn(250);
        $('.nav-lv1 a').removeClass('active');
        $(this).addClass('active');
        $(this).parent().find('.watermark').slideDown('fast');
        $('.slide-menu-wrapper').slideDown('fast');
        $('.menu_iframe').slideDown('fast');
        currMenu = theClass;
      } else {
        currMenu = null;
      }
    }
  });

  // $('.sbnav-lv1 > li > a').click(function(e){
  //     e.preventDefault();
  //     $('.sbnav-lv1 > li').removeClass('active');
  //     $(this).parent().addClass('active');
  // });

  $('.sbnav-lv1 > li').click(function (e) {
    if (checkHref2go(e.target)) {
      e.preventDefault();
    }
    subMenuToggle(this, '.sbnav-lv2', 'show');
  });
  $('.sbnav-lv2 > li').click(function (e) {
    if (checkHref2go(e.target)) {
      e.preventDefault();
    }
    subMenuToggle(this, '.sbnav-lv3', 'show');
  });

  hoverSubMenu('.sbnav-lv1 > li', '.sbnav-lv2');
  hoverSubMenu('.sbnav-lv2 > li', '.sbnav-lv3');
  function hoverSubMenu(main, sub) {
    var timeout;
    var currSubMenu = undefined;
    $(main).hover(
      function () {
        var $this = this;
        timeout = setTimeout(function () {
          if (currSubMenu != $this) {
            subMenuToggle(currSubMenu, sub, 'hide');
            currSubMenu = $this;
          }
          subMenuToggle($this, sub, 'show');
        }, 300);
      },
      function () {
        clearTimeout(timeout);
      }
    );
  }

  $('.sbnav-lv2 > li').each(function () {
    if ($(this).find('.sbnav-lv3').length) {
      $(this).find('> a').addClass('sbnav-arrow');
    }
  });

  function subMenuToggle(data, selector, toggle) {
    if (toggle == 'show') {
      $(data).find(selector).length &&
        $(data).find(selector).show('slide', { direction: 'left' }, 'fast') &&
        $(data)
          .find('.sbnav-iframe')
          .show('slide', { direction: 'left' }, 'fast');
    } else if (toggle == 'hide') {
      $(data).find(selector).length &&
        $(data).find(selector).hide('slide', { direction: 'left' }, 'fast') &&
        $(data)
          .find('.sbnav-iframe')
          .hide('slide', { direction: 'left' }, 'fast');
    }
  }

  var currSlide = undefined;
  cycleSlide = $('.cycle-slideshow');
  cycleSlide.on('cycle-update-view', function (e, optionHash, API, html) {
    if (currSlide != API.currSlide) {
      overlay_block = API.cycleOverlayCustom;
      overlay_tpl_block = API.cycleOverlayCustomTemplate;
      overlay_target = $(html).find(overlay_tpl_block)[0].outerHTML;
      $(overlay_block).html(overlay_target);
      $(overlay_block + ' ' + overlay_tpl_block).fadeIn('fast');
      currSlide = API.currSlide;
    }
  });
  cycleSlide.on('cycle-initialized', function (e, optionHash) {
    $('.cycle-pager').find('span:first-child').addClass('home').text('主選單');
  });

  $('.abgne-tab2 ul > li > a').click(function (e) {
    e.preventDefault();
    $(this)
      .addClass('active')
      .parent()
      .siblings()
      .find('a')
      .removeClass('active');
    $target = $(this).attr('href');
    $($target).fadeIn().siblings().hide();
  });

  // 預設顯示第一個 Tab
  var _showTab = 0;
  $('.abgne_tab').each(function () {
    // 目前的頁籤區塊
    var $tab = $(this);

    //var $defaultLi = $('ul.tabs li', $tab).eq(_showTab).addClass('active');
    //$($defaultLi.find('a').attr('href')).siblings().hide();
    var $defaultLi = $('ul.tabs li').eq(_showTab).addClass('active');
    if (location.hash != '') {
      $defaultLi = $('ul.tabs li a[href=' + location.hash + ']')
        .parent()
        .addClass('active')
        .siblings('.active')
        .removeClass('active')
        .end();
    }
    $($defaultLi.find('a').attr('href')).siblings().hide();

    // 當 li 頁籤被點擊時...
    // 若要改成滑鼠移到 li 頁籤就切換時, 把 click 改成 mouseover
    $('ul.tabs li', $tab)
      .click(function () {
        // 找出 li 中的超連結 href(#id)
        var $this = $(this),
          _clickTab = $this.find('a').attr('href');
        // 把目前點擊到的 li 頁籤加上 .active
        // 並把兄弟元素中有 .active 的都移除 class
        $this.addClass('active').siblings('.active').removeClass('active');
        // 淡入相對應的內容並隱藏兄弟元素
        $(_clickTab).stop(false, true).fadeIn().siblings().hide();

        let liFourth = $('ul.tabs--tabsCen li:lt(4)');
        let creRe = $('ul.tabs--tabsCen li:nth-child(5)');
        let hisRate = $('ul.tabs--tabsCen li:nth-child(6)');

        let exR = $('ul.exRate li:nth-child(1)');
        let exRG = $('ul.exRate li:nth-child(2)');
        let conCur = $('ul.exRate li:nth-child(3)');
        var descP = $('.infopage-content > p');
        if ($(this).is(creRe)) {
          showContent(2);
        } else if ($(this).is(hisRate)) {
          showContent(3);
        } else if ($(this).is(exR)) {
          showContent(1);
        } else if ($(this).is(exRG)) {
          showContent(2);
        } else if ($(this).is(conCur)) {
          showContent(3);
        } else if ($(this).is(liFourth)) {
          showContent(1);
        }

        function showContent(index) {
          descP
            .hide()
            .siblings('.infopage-content > p:nth-child(' + index + ')')
            .show();
        }
        return false;
      })
      .find('a')
      .focus(function () {
        this.blur();
      });
  });

  //JS TABS 2ND LEVEL//

  $('#tab-content_2 > div').hide();
  $('#tab-content_2 div:first').show();

  $('#nav_2 li').click(function () {
    $('#nav_2 li').removeClass('active');
    $(this).addClass('active');
    $('#tab-content_2 > div').hide();

    var indexer = $(this).index(); //gets the current index of (this) which is #nav li
    $('#tab-content_2 > div:eq(' + indexer + ')').fadeIn(); //uses whatever index the link has to open the corresponding box
  });
  function checkFooterbdTop() {
    if ($('footer').hasClass('less')) {
      $('footer').removeClass('less');
    } else {
      $('footer').addClass('less');
    }
  }
  function updateScrollbar() {
    $scrolling_table.data('plugin_tinyscrollbar').update();
  }

  function checkHref2go(data) {
    href = $(data).attr('href');
    if (href == '#' || href == '' || href == undefined) {
      return true;
    }
    return false;
  }
  (function ($) {
    $.fn.ie89placeholder = function () {
      var ua = window.navigator.userAgent,
        msie = ua.indexOf('MSIE '),
        ieVer = 0;

      if (msie > 0) {
        ieVer = parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)));
      }

      if (ieVer > 9 || ieVer < 7) {
        return true;
      }

      $(this).each(function () {
        $(this)
          .closest('.rowElem')
          .find('.ie89placeholder')
          .text($(this).attr('placeholder'))
          .show()
          .click(function () {
            $(this).hide().closest('.rowElem').find('input').focus();
          });
      });
      $(this).focus(function () {
        $(this).closest('.rowElem').find('.ie89placeholder').hide();
      });
      $(this).blur(function () {
        if ($(this).val() == '') {
          $(this).closest('.rowElem').find('.ie89placeholder').show();
        }
      });
    };
  })(jQuery);

  var toggleFoot = 0;
  $('.toggle-footlist').click(function () {
    toggleFoot ^= 1;
    $('footer .footer-list').slideToggle({
      duration: 400,
      start: function () {
        if (toggleFoot) {
          checkFooterbdTop();
        }
        $('html, body').animate(
          {
            scrollTop: document.body.scrollHeight,
          },
          400
        );
      },
      complete: function () {
        if (!toggleFoot) {
          checkFooterbdTop();
        }
        $('.toggle-footlist .tglfl')
          .eq(toggleFoot ^ 1)
          .fadeOut(100, function () {
            $('.toggle-footlist .tglfl').eq(toggleFoot).fadeIn();
          });
      },
    });
  });

  /*for mainmenu*/
  //$(".lv1").click(function(){
  //     var lv1 = $(this).parent();
  //     var sign = $(lv1).find('.lv1a').attr('data-sign');
  //     sign ^= 1;
  //    $(lv1).find('.lv2').slideToggle('normal',function(){
  //         $(lv1).find('.lv1a').css('background-image','url(/MMA8/bank/images/lv1_open.jpg)');
  //         if (sign == 0) {
  //            $(lv1).find('.lv1a').css('background-image','url(/MMA8/bank/images/lv1_close.jpg)');
  //        }
  //       $(lv1).find('.lv1a').attr('data-sign',sign);
  //    });
  // });
  $(function () {
    $('.lv1')
      .hover(
        function () {
          $(this).addClass('lv1_on');
        },
        function () {
          $(this).removeClass('lv1_on');
        }
      )
      .click(function () {
        // 當點到標題時，若答案是隱藏時則顯示它；反之則隱藏
        $(this).next('.lv2').slideToggle();
        $(this).find('.lv1a').toggleClass('lv1_active');
      });
  });
  // 全部展開
  $('#magicbtn')
    .data('hide', 'tgl')
    .click(function () {
      if ($(this).data('tgl') == 'hide') {
        $('.lv2').hide(200);
        $(this).data('tgl', 'show');
        $(this).html('全部展開');
        $('.lv1a').removeClass('lv1_active');
      } else {
        -$('.lv2').show(200);
        $(this).data('tgl', 'hide');
        $(this).html('全部收合');
        $('.lv1a').addClass('lv1_active');
      }
    });

  $('.pqa-container_1 ul.menu a,#magicbtn').click(function (e) {
    e.preventDefault();
  });

  var sourceSwap = function () {
    var $this = $(this);
    var newSource = $this.data('alt-src');
    $this.data('alt-src', $this.attr('src'));
    $this.attr('src', newSource);
  };

  // 201912
  // service-download.html 新增 menu slider 功能
  clickPqaSlider();
  function clickPqaSlider() {
    $('.pqa-cat-arrow-r').on('click', function () {
      $(this).removeClass('active');
      $('.pqa-cat-arrow-l').addClass('active');
      $('.pqa-cat-inner').addClass('move');
    });
    $('.pqa-cat-arrow-l').on('click', function () {
      $(this).removeClass('active');
      $('.pqa-cat-arrow-r').addClass('active');
      $('.pqa-cat-inner').removeClass('move');
    });
  }
});

$(function () {
  $('.ffTextBoxWrapper input').each(function () {
    $(this).val($(this).attr('placeholder'));
    $(this).addClass('blur');
  });
  $('.ffTextBoxWrapper input').focus(function () {
    if ($(this).val() == $(this).attr('placeholder')) {
      $(this).val('');
      $(this).removeClass('blur');
    }
  });
  $('.ffTextBoxWrapper input').blur(function () {
    if ($(this).val() == '') {
      $(this).val($(this).attr('placeholder'));
      $(this).addClass('blur');
    }
  });
});

function dotableradius() {
  $('.infopage .data-table1').each(function () {
    $(this).find('tr').first().find('th').first().addClass('top-left');
  });
  $('.infopage .data-table1').each(function () {
    $(this).find('tr').first().find('th').last().addClass('top-right');
  });
  $('.infopage .data-table1').each(function () {
    $(this).find('tr').last().find('td').first().addClass('bottom-left');
  });
  $('.infopage .data-table1').each(function () {
    $(this).find('tr').last().find('td').last().addClass('bottom-right');
  });
  $('.infopage .data-table1 tr').each(function () {
    $(this).find('td:last,th:last').addClass('lastcolumn');
  });
  $('.infopage .data-table1').each(function () {
    $(this).find('tr').last().find('td,th').addClass('last-child');
  });

  $('.data-table2').each(function () {
    $(this).find('tr').first().find('th').first().addClass('top-left');
  });
  $('.data-table2').each(function () {
    $(this).find('tr').first().find('th').last().addClass('top-right');
  });
  $('.data-table2').each(function () {
    $(this).find('tr').last().find('td').first().addClass('bottom-left');
  });
  $('.data-table2').each(function () {
    $(this).find('tr').last().find('td').last().addClass('bottom-right');
  });
  $('.data-table2 tr').each(function () {
    $(this).find('td:last,th:last').addClass('lastcolumn');
  });
  $('.data-table2').each(function () {
    $(this).find('tr').last().find('td,th').addClass('last-child');
  });
}

(function ($) {
  $.fn.dropdown = function () {
    var ua = window.navigator.userAgent,
      isMac = navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i)
        ? true
        : false,
      msie = ua.indexOf('MSIE '),
      winnt = ua.indexOf('Windows NT '),
      ieVer = 0,
      WinVer = 0,
      selector = this.selector;

    if (msie == -1) {
      msie = ua.indexOf('; rv:');
    }
    if (msie > 0) {
      ieVer = parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)));
    }
    if (winnt > 0) {
      WinVer = parseFloat(ua.substring(winnt + 11, ua.indexOf(';', winnt)));
    }

    $('body').delegate(selector, 'mouseenter', function () {
      if ($(this).data('dpstate') == 'rendered') {
        return true;
      }
      var obj = $(this),
        options = obj.find('.options'),
        select = obj.find('.select'),
        selected = obj.find('.selected');

      if (ieVer > 0 && WinVer > 6.1) {
        overoption = false;
        $(options).hover(
          function () {
            overoption = true;
          },
          function () {
            overoption = false;
          }
        );
        $(document).mouseup(function (e) {
          if (!overoption) {
            $(options).slideUp('fast');
          }
        });
      } else {
        $(document).mouseup(function (e) {
          if (!options.is(e.target) && options.has(e.target).length === 0) {
            $(options).slideUp('fast');
          }
        });
      }

      if (isMac) {
        obj.addClass('macscroll');
      }

      select.click(function () {
        if (obj.hasClass('disabled')) {
          return false;
        }
        if (!options.is(':visible')) {
          options.slideDown('fast');
        } else {
          options.slideUp('fast');
        }
      });

      options.delegate('li', 'click', function () {
        options.slideUp('fast').find('li').removeClass('on');
        $(this).addClass('on');
        selected.text($(this).text());
        obj
          .find('input[type="hidden"]')
          .val($(this).data('value') ? $(this).data('value') : $(this).text());
      });

      if (selected.hasClass('disabled')) {
        obj.addClass('disabled');
      }

      obj.data('dpstate', 'rendered');
    });
    return this;
  };
})(jQuery);
