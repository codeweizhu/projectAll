function gsapAni() {
  console.log("succee");
  var tlKv = gsap.timeline({
    delay: 0.7,
    onStart: function () {
      window.scrollTo(0, 0);
    },
  });

  tlKv
    .addLabel("kvStart")
    .from(
      ".text__Img > *",
      {
        scale:0,ease:"elastic.out(1, 0.35)",duration:1.5,stagger:.8,clearProps:"all"
      },
      "kvStart+=0.25"
    )
    .from('.kv__cigarette > *', {
      opacity: 0,
      // scale: 0.5
      duration: 2.5,
      ease: "elastic.out(1, 0.35)",
      stagger:.8,
      clearProps: 'all'
    }, 'kvStart+=0.5')
}
