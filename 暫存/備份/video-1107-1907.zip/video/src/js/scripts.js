//@prepros-prepend gsapAnim.js
//@prepros-prepend scrollAnim.js

(function () {
  //- 執行Gsap動態效果
  gsapAni();

  //- 處理非IE的滑鼠事件
  var IE =
    window.navigator.userAgent.indexOf("MSIE ") > 0 ||
    !!navigator.userAgent.match(/Trident.*rv\:11\./);
  if (!IE) {
    document.body.addEventListener("mousemove", function (e) {
      document.body.style.setProperty("--x", e.clientX);
      document.body.style.setProperty("--y", e.clientY);
      // console.log(e.pageX, e.pageY);
    });
    document.querySelectorAll(".nav__link").forEach(function (link) {
      link.addEventListener("mouseover", function () {
        document.querySelector(".cursor").classList.add("cursor--active");
        // console.log(1);
      });
      link.addEventListener("mouseleave", function () {
        document.querySelector(".cursor").classList.remove("cursor--active");
        // console.log(2);
      });
    });
    document.querySelectorAll(".primary, .highlight").forEach(function (link) {
      link.addEventListener("mouseover", function () {
        document.querySelector(".cursor").classList.add("cursor--highlight");
        // console.log(3);
      });
      link.addEventListener("mouseleave", function () {
        document.querySelector(".cursor").classList.remove("cursor--highlight");
        // console.log(4);
      });
    });
  }

  //- notice開關
  $(".notice__toggle").click(function (e) {
    e.preventDefault(); // 阻止默認的連結跳轉行為
    $(".notice").toggleClass("notice--active");
    $(".notice__content").slideToggle();
    $("html, body").animate(
      {
        scrollTop: $(".section-notice").offset().top,
      },
      300
    );
  });

  //- 點擊選單滑動到錨點位置
  $(".header-nav__trigger").click(function (e) {
    e.preventDefault();
    // 切換 '.header-nav' 元素的 'header-nav--active' 類別，用於控制導航欄的顯示/隱藏
    $(".header-nav").toggleClass("header-nav--active");
  });
  // 當不具有 '.header-nav__link--highlight' 類別的導航連結元素被點擊時，觸發以下操作
  $(".header-nav__link:not(.header-nav__link--highlight)").click(function (e) {
    e.preventDefault();
    // 獲取被點擊連結的 'href' 屬性值，該值是頁面中某個錨點的識別符（通常是ID）
    var anchorID = $(this).attr("href");
    // 使用動畫效果平滑地捲動到具有對應ID的元素位置
    $("html, body").animate(
      {
        scrollTop: $(anchorID).offset().top - 100,
      },
      500
    );
  });

  // LightBox 顯示 //
  function LightBoxTargetShow(target) {
    var lightbox = document.querySelector(".lightbox");
    // 開啟遮罩
    document.body.classList.add("scroll-fixed");

    // 關閉 Lightbox
    var close_lightbox = function (e) {
      // console.log('close');
      lightbox.classList.remove("lightbox--active");
      document.body.classList.remove("scroll-fixed");
      return false;
    };
    document
      .querySelector(".lightbox__btn-close")
      .addEventListener("click", function (e) {
        close_lightbox();
        return false;
      });

    // 開啟 Lightbox
    lightbox.classList.add("lightbox--active");
    return false;
  }

  //- LightBox預設開啟 註解掉就不會SHOW嘿
  // LightBoxTargetShow('#msg');

  //-按下按鈕才開啟Lightbox的話請參考以下
  // 找到按鈕元素
  var openButton = document.getElementById("openLightboxButton");
  // 為按鈕添加點擊事件監聽器
  if (openButton) {
    openButton.addEventListener("click", function (e) {
      // 調用 LightBoxTargetShow 函數來開啟 Lightbox
      LightBoxTargetShow("#msg");
    });
  }

  // copyright console
  if (navigator.userAgent.toLowerCase().indexOf("chrome") > -1) {
    var a = [
      "\n\n %c Developed by Bank SinoPac. -> https://bank.sinopac.com/ \n\n",
      "background: #254a91; padding:5px 0;color: #ffffff;",
    ];
    console.log.apply(console, a);
  } else {
    console.log("Developed by Bank SinoPac. -> https://bank.sinopac.com/");
  }
  var elms = document.getElementsByClassName("splide");

  for (var i = 0; i < elms.length; i++) {
    new Splide(elms[i]).mount();
  }

  //切換QA
  //- $(function () {
  //-   $(".problem__box").click(function () {
  //-     $(".problem__content").hide();
  //-     $(this).next().toggle();
  //-   });
  //- });
  $(function () {
    $(".problem__box").click(function () {
      $(this).next().toggle();
    });
  });

  //切換服務項目
  $(function () {
    $("#account").on("click", () => {
      $(".container_out").hide();
      $("#accountInfo").show();
      $(".service__button").removeClass("itemCheck");
      $("#account").addClass("itemCheck");
    });

    $("#access").on("click", () => {
      $(".container_out").hide();
      $("#accessInfo").show();
      $(".service__button").removeClass("itemCheck");
      $("#access").addClass("itemCheck");
    });

    $("#bankapp").on("click", () => {
      $(".container_out").hide();
      $("#bankappInfo").show();
      $(".service__button").removeClass("itemCheck");
      $("#bankapp").addClass("itemCheck");
    });

    $("#dawhoapp").on("click", () => {
      $(".container_out").hide();
      $("#dawhoappInfo").show();
      $(".service__button").removeClass("itemCheck");
      $("#dawhoapp").addClass("itemCheck");
    });
  });

  //切換立即下載
  $(function () {
    $("#dawho_info").on("click", () => {
      $("#bank_info").removeClass("downloadCheck");
      $("#bank_content").hide();
      $("#dawho_content").show();
      $("#dawho_info").addClass("downloadCheck");
    });

    $("#bank_info").on("click", () => {
      $("#dawho_info").removeClass("downloadCheck");
      $("#dawho_content").hide();
      $("#bank_content").show();
      $("#bank_info").addClass("downloadCheck");
    });
  });

  //預選狀態--arrow
  $(function () {
    $(".splide__arrow--next").on("click", () => {
      $(".splide__arrow--prev").removeClass("arrowCheck");
      $(".splide__arrow--next").css("background", "#5c49d5");
    });

    $(".splide__arrow--prev").on("click", () => {
      $(".splide__arrow--prev").addClass("arrowCheck");
      $(".splide__arrow--next").css("background", "white");
    });
  });

  //mb-切換服務項目
  $(function () {
    $("#accessBtn").on("click", () => {
      $(".service__button").removeClass("itemCheck");
      $("#accessBtn").addClass("itemCheck");
      $(".container_out").hide();
      $("#accessMb").show();
    });

    $("#bankBtn").on("click", () => {
      $(".service__button").removeClass("itemCheck");
      $("#bankBtn").addClass("itemCheck");
      $(".container_out").hide();
      $("#bankMb").show();
    });

    $("#dawhoBtn").on("click", () => {
      $(".service__button").removeClass("itemCheck");
      $("#dawhoBtn").addClass("itemCheck");
      $(".container_out").hide();
      $("#dawhoMb").show();
    });

    $("#accountBtn").on("click", () => {
      $(".service__button").removeClass("itemCheck");
      $("#accountBtn").addClass("itemCheck");
      $(".container_out").hide();
      $("#accountMb").show();
    });
  });

  //mb-立即下載
  $(function () {
    $("#dawhoApp").on("click", () => {
      $(".service__button").removeClass("downloadCheck");
      $("#dawhoApp").addClass("downloadCheck");
      $("#bankContent").hide();
      $("#dawhoContent").show();
    });

    $("#bankApp").on("click", () => {
      $(".service__button").removeClass("downloadCheck");
      $("#bankApp").addClass("downloadCheck");
      $("#dawhoContent").hide();
      $("#bankContent").show();
    });
  });

  //  滑動至頂
  $("#goTop").click(function () {
    $("html,body").animate({ scrollTop: 0 }, 800);
  });
  // 置頂按鈕淡出淡入
  $(window).scroll(function () {
    if ($(this).scrollTop() > 200) {
      $("#goTop").stop().fadeTo("", 5);
    } else {
      $("#goTop").stop().fadeOut();
    }
  });

  //hamburger
  $(function () {
    $(".hamburger").on("click", () => {
      $(".hamburger").toggleClass("is-active");
      $("#hamItemContent").toggle();
    });

    $("#mb__Menu a").on("click", () => {
      $(".hamburger_nav").hide();
      $(".hamburger").removeClass("is-active");
    });
  });

  //smooth
  $("#menu a").click(function () {
    var btn = $(this).attr("href");
    var pos = $(btn).offset();
    $("html,body").animate({ scrollTop: pos.top }, 1300);
  });
})();

//監聽是否IE瀏覽器

let parent = document.querySelector(".problem__box");
let child = parent.querySelector(".js-animate");

let isIE = /MSIE|Trident/.test(navigator.userAgent);
if (isIE) {
  // 使用者正在使用 Internet Explorer
  parent.removeChild("child");
  console.log("This is Internet Explorer.");
} else {
  // 使用者不是使用 Internet Explorer
  console.log("This is not Internet Explorer.");
}
