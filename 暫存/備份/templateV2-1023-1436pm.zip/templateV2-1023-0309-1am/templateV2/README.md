# 資料夾結構

```
template
├── css
│   └── styles.css                # build過最終產生出來的css
├── images                        # 圖檔
├── js                            # 壓縮過的js
│   ├── ...                         引用的套件的js也可以直接放這裡，資安因素副檔名一律改為securejs
│   ├── library.securejs
│   └── scripts.securejs
├── src
│   ├── js                        # 尚未build過的js資料夾
│   │   ├── gsapAnim.js             - 動態效果的js可寫在此
│   │   ├── scripts.js              - 主js
│   │   └── scrollAnim.js           - 將元素滑動至上的script
│   ├── scss
│   │   ├── _base.scss            # 一些地圖砲的設定，如 body、img等。包含media query。
│   │   ├── _carousel.scss        # 輪播套件
│   │   ├── _font.scss            # 字型設定
│   │   ├── _footer.scss          # FOOTER
│   │   ├── _forms.scss           # 表單設定
│   │   ├── _header.scss          # HEADER
│   │   ├── _icon.scss            # ICON集中營
│   │   ├── _js-animates.scss     # scroll Animations
│   │   ├── _keyframes.scss       # CSS3 Animations
│   │   ├── _lightbox.scss        # 燈箱
│   │   ├── _loading.scss         # 載入動畫
│   │   ├── _master.scss          # Desktop版css
│   │   ├── _public.scss          # 跨載具共用的地圖砲
│   │   ├── _reset.scss           # CSS RESET
│   │   ├── _rwd-mobiles.scss     # Mobile版CSS
│   │   ├── _rwd-pc-mid.scss      # 介於DESKTOP與MOBILE之間的尺寸 PAD大多在這區域
│   │   ├── _variables.scss       # ★變數設定，包含Media query的break point設定
│   │   └── styles.scss           # >>>主體<<< import其他以上的SCSS檔
│   ├── _layout.pug               # layout
│   ├── _lightbox.pug             # 燈箱
│   └── index.pug                 # index
├── index.html
├── prepros-6.config
└── README.md

```

# pug變數設定技巧

- 範例一
  block vars
    - var og_desc = '這裡是描述'
    - var header_title = '網站名'
  head
    meta(name='description', content='這裡是描述')
    title= header_title

  產出的HTML：
  <!DOCTYPE html>
  <html>
    <head>
      <meta name="description" content="這裡是描述">
      <title>網站名</title>
    </head>
    <body></body>
  </html>

- 引申
  title #{og_title ? og_title + ' | ' + author : ''}
  =>意思是og_title有值的話 title等於og_title | author ，沒值的話則留空。


- 範例二
  var vars
    - var idDawho = true
  body  
    - var isDawho = (product === 'dawho' || product === 'dawhoAPP' || product === 'daApply')
    .email-content(style=isDawho ? "max-width: 752px; margin: 0 auto;" : "max-width: 800px; margin: 0 auto;")

  產出的HTML：
  <!DOCTYPE html>
  <html>
    <head></head>
    <body>
      <div class="email-content" style="max-width: 752px; margin: 0 auto;"></div>
    </body>
  </html>

# CSS function應用
- 請移駕 css_example.scss

# 動態效果傳送門
-[gsap官網] https://greensock.com/gsap/
-[gsap教學中文] https://jaywu-fe.medium.com/%E5%85%A5%E9%96%80-gsap-%E6%95%99%E5%AD%B8-9131afdbed04
-[大額換匯推廣頁] http://10.5.130.3/html/vipexchange/
-[DAWHO請你喝咖啡活動] http://10.5.130.3/html/coffee/
-[gitlab] http://10.5.130.2/prepros

# 輪播套件
- 請全站搜尋hasCarousel，確認在scss和pug中值都一致。若有輪播都會是true，沒輪播皆改為false。





# 提醒事項
- **弱掃：** 弱掃請洽 資訊處-企網平台科 [藍嘉村](mailto:bruce.lan@sinopac.com)， 同時CC **負責PM** 知悉，理想時間是抓上線前三天提供送弱掃
- **DMP神策：** 請洽 數金處-數據經營科 [許雅喬](mailto:chiao.hsu@sinopac.com)
- **SEO：** 請洽 數金處-數據經營科 [楊奕嫻](mailto:jossyang@sinopac.com)
- **上傳問題：** 撇除數金以外單位 需上傳但無權限請PM自行洽 綜合企劃處-行銷規劃科
[顏麗芳](mailto:eva.yen@sinopac.com)

- **[請隨手更新EXCEL \\10.11.140.97\Frontend\前端\DAWHO_link.xlsx](\\10.11.140.97\Frontend\前端\DAWHO_link.xlsx)**
- **[教學文件路徑](\\10.11.140.97\Frontend\前端\教學文件\行銷頁檢查SOP.pptx)**