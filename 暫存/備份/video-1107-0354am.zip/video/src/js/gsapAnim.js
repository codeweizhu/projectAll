function gsapAni() {
  // console.log("succee");
  var tlKv = gsap.timeline({
    delay: 0.7,
    onComplete: aniLoop,
    onStart: function () {
      window.scrollTo(0, 0);
    },
  });

  tlKv
    .addLabel("kvStart")
    .from(
      ".text__Img > *",
      {
        scale: 0,
        ease: "elastic.out(1, 0.35)",
        duration: 1.5,
        stagger: 0.8,
        clearProps: "all",
      },
      "kvStart+=0.25"
    )
    .from(
      ".kv__cigarette > *",
      {
        opacity: 0,
        duration: 2.5,
        ease: "elastic.out(1, 0.35)",
        stagger: 0.8,
        clearProps: "all",
      },
      "kvStart+=0.5"
    );

  function aniLoop() {
    gsap
      .timeline({
        delay: 0.5,
        repeat: -1,
        repeatDelay: 2,
      })
      .from(
        ".bankImg",
        {
          scale: 0,
          opacity: 0,
          duration: 1.5,
          ease: "elastic.out(1, 0.35)",
          clearProps: "all",
          stagger: 0.8,
        },
        "kvStart+=0.5"
      )
      .from(
        ".viewImg",
        {
          scale: 0,
          opacity: 0,
          duration: 1.5,
          ease: "elastic.out(1, 0.35)",
          clearProps: "all",
          stagger: 0.8,
        },
        "kvStart+=1.4"
      )
      .from(
        ".sloganImg",
        {
          scale: 0,
          opacity: 0,
          duration: 1.5,
          ease: "elastic.out(1, 0.35)",
          clearProps: "all",
          stagger: 0.8,
        },
        "kvStart+=2.1"
      )
      .to(
        ".kv__cigarette > *",
        {
          opacity: 0,
          clearProps: "all",
          stagger: 0.8,
          duration: 2.5,
        },
        "kvStart+=0.5"
      );
  }
}
