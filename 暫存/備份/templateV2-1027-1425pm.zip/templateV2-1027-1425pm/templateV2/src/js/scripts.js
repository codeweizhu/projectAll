//@prepros-prepend gsapAnim.js
//@prepros-prepend scrollAnim.js



(function () {
  //- 處理非IE的滑鼠事件
  var IE =
    window.navigator.userAgent.indexOf('MSIE ') > 0 ||
    !!navigator.userAgent.match(/Trident.*rv\:11\./);
  if (!IE) {
    document.body.addEventListener('mousemove', function (e) {
      document.body.style.setProperty('--x', e.clientX);
      document.body.style.setProperty('--y', e.clientY);
      // console.log(e.pageX, e.pageY);
    });
    document.querySelectorAll('.nav__link').forEach(function (link) {
      link.addEventListener('mouseover', function () {
        document.querySelector('.cursor').classList.add('cursor--active');
        // console.log(1);
      });
      link.addEventListener('mouseleave', function () {
        document.querySelector('.cursor').classList.remove('cursor--active');
        // console.log(2);
      });
    });
    document.querySelectorAll('.primary, .highlight').forEach(function (link) {
      link.addEventListener('mouseover', function () {
        document.querySelector('.cursor').classList.add('cursor--highlight');
        // console.log(3);
      });
      link.addEventListener('mouseleave', function () {
        document.querySelector('.cursor').classList.remove('cursor--highlight');
        // console.log(4);
      });
    });
  }

  //- notice開關
  $('.notice__toggle').click(function (e) {
    e.preventDefault(); // 阻止默認的連結跳轉行為
    $('.notice').toggleClass('notice--active');
    $('.notice__content').slideToggle();
    $('html, body').animate(
      {
        scrollTop: $('.section-notice').offset().top,
      },
      300
    );
  });

  //- 點擊選單滑動到錨點位置
  $('.header-nav__trigger').click(function (e) {
    e.preventDefault();
    // 切換 '.header-nav' 元素的 'header-nav--active' 類別，用於控制導航欄的顯示/隱藏
    $('.header-nav').toggleClass('header-nav--active');
  });
  // 當不具有 '.header-nav__link--highlight' 類別的導航連結元素被點擊時，觸發以下操作
  $('.header-nav__link:not(.header-nav__link--highlight)').click(function (e) {
    e.preventDefault();
    // 獲取被點擊連結的 'href' 屬性值，該值是頁面中某個錨點的識別符（通常是ID）
    var anchorID = $(this).attr('href');
    // 使用動畫效果平滑地捲動到具有對應ID的元素位置
    $('html, body').animate(
      {
        scrollTop: $(anchorID).offset().top - 100,
      },
      500
    );
  });

  //- 執行Gsap動態效果
  gsapAni();


  // LightBox 顯示 //
  function LightBoxTargetShow(target) {
    var lightbox = document.querySelector('.lightbox');
    // 開啟遮罩
    document.body.classList.add('scroll-fixed');


    // 關閉 Lightbox
    var close_lightbox = function (e) {
      // console.log('close');
      lightbox.classList.remove('lightbox--active');
      document.body.classList.remove('scroll-fixed');
      return false;
    };
    document
      .querySelector('.lightbox__btn-close')
      .addEventListener('click', function (e) {
        close_lightbox();
        return false;
      });

    // 開啟 Lightbox
    lightbox.classList.add('lightbox--active');
    return false;
  }

  //- LightBox預設開啟 註解掉就不會SHOW嘿
  // LightBoxTargetShow('#msg');


  //-按下按鈕才開啟Lightbox的話請參考以下
  // 找到按鈕元素
  // var openButton = document.getElementById('openLightboxButton');
  // // 為按鈕添加點擊事件監聽器
  // if (openButton) {
  //     openButton.addEventListener('click', function (e) {
  //     // 調用 LightBoxTargetShow 函數來開啟 Lightbox
  //     LightBoxTargetShow('#msg'); 
  //   });
  // }  

  // copyright console
  if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
    var a = [
      '\n\n %c Developed by Bank SinoPac. -> https://bank.sinopac.com/ \n\n',
      'background: #254a91; padding:5px 0;color: #ffffff;',
    ];
    console.log.apply(console, a);
  } else {
    console.log('Developed by Bank SinoPac. -> https://bank.sinopac.com/');
  }
  var elms = document.getElementsByClassName( 'splide' );

  for ( var i = 0; i < elms.length; i++ ) {
    new Splide( elms[ i ] ).mount();
  }
  
})();
