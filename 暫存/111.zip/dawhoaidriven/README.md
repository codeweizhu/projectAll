# 大戶 AI Driven dawhoaidriven

#20230808 #大戶 #AI Driven


### 前端：股感
### PM：鄭富僑、陳品安、陳品妤、黃莉惟、蔡芷琳

**活動登錄 串接 EventSiteApi**
```
  var urlPost = 'https://mma.sinopac.com/EventSiteApi/EntryPostHx.ashx';
  var urlCaptcha = 'https://mma.sinopac.com/EventSiteApi/CaptchaImage.ashx';
```
---
```
dawhoaidriven
├─css
│  └─libs
├─font
├─img
│  ├─aside
│  ├─bg
│  ├─icons
│  ├─main
│  ├─platform
│  └─popup
├─js
│  └─lib
└─src
    └─scss
    └─_layout.pug
    └─index.pug
```